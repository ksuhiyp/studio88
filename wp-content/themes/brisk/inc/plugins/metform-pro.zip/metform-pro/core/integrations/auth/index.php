<?php

// Life is 10% what happens to you and 90% how you react to it.