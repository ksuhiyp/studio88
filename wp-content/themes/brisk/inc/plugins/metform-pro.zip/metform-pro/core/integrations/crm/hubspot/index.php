<?php
// Well done is better than well said.