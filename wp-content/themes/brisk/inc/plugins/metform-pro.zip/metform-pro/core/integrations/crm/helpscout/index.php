<?php
// You only live once, but if you do it right, once is enough. 