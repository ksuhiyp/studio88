<li>
    <a class="attr-nav-item attr-nav-link" data-toggle="tab" href="#automizy-tab" role="tab" aria-controls="nav-profile" aria-selected="false"><?php esc_html_e('Automizy', 'metform-pro'); ?></a>
</li>