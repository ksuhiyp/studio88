<?php

namespace MetForm_Pro\Core\Integrations;


class Mail_Adapter implements Mail_Adapter_Contract {

	public function get_token() {

	}


	public function get_adapter(){

	}
}