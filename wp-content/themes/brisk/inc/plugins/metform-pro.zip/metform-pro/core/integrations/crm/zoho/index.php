<?php
// You may delay, but time will not